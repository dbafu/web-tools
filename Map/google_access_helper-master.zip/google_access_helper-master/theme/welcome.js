if(window.navigator.userAgent.match(/(LBBROWSER)/i)){
	document.getElementById("sethomepage").setAttribute("href","http://www.ggfwzs.com/setliebao/");
}else if(window.navigator.userAgent.match(/(BIDUBrowser)/i)){
	document.getElementById("sethomepage").setAttribute("href","http://www.ggfwzs.com/setbaidu/");
}